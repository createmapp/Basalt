import React from 'react';
import { Award, Brain, Users, Globe } from 'lucide-react';

const About = () => {
  const features = [
	{
      icon: Award,
      title: 'Global consulting',
      description: 'With deep industry expertise and worldwide reach, we deliver solutions that drive sustainable growth. Partner with us to transform ambition into measurable impact across markets'
    },
    {
      icon: Brain,
      title: 'Intelligent Platform',
      description: 'Unified AI, automation, and data insights to power smarter decisions at scale. Built for agility and security, seamlessly integrates with the business ecosystem'
    },
    {
      icon: Users,
      title: 'Digital transformation',
      description: 'Empower with digital transformation that accelerates efficiency. Integrate cutting-edge technologies to modernize operations and enhance customer experiences.'
    },    
    {
      icon: Globe,
      title: 'Innovation',
      description: 'Empowering organizations to stay ahead through continuous evolution and breakthrough thinking.'
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">       

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {features.map((feature, index) => (
            <div key={index} className="text-center group">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-600 transition-colors duration-300">
                <feature.icon className="h-8 w-8 text-blue-600 group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl p-8 lg:p-12 text-white">
          <div className="grid lg:grid-cols-3 gap-8 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-4">Our Vision</h3>
              <p className="text-lg leading-relaxed mb-6">
                To be the world’s most trusted partner in AI-driven digital solutions—empowering businesses to achieve their full potential through intelligent automation, resilient infrastructure, and actionable insights.
              </p>
              <div className="grid grid-cols-2 gap-4">
                
              </div>
            </div>
            <div className="space-y-2">
              <h4 className="text-3xl font-bold mb-4">Core Values</h4>
              
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                  <span className="text-lg1">Innovation-driven solutions</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                  <span className="text-lg1">Customer-centric approach</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                  <span className="text-lg1">Security and compliance</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                  <span className="text-lg1">Sustainable digital transformation</span>
                </li>
              
            </div>
            <div className="lg:col-span-1">
              <div className="relative rounded-xl overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=600" 
                  alt="AI and Machine Learning Technology"
                  className="w-full h-48 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;