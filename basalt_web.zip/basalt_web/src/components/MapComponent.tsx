// MapLeaflet.tsx

import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";

import "leaflet/dist/leaflet.css";

import L from "leaflet";
 
// Fix for default marker icons in Leaflet

import iconUrl from "leaflet/dist/images/marker-icon.png";

import shadowUrl from "leaflet/dist/images/marker-shadow.png";
 
const customIcon = L.icon({

  iconUrl,

  shadowUrl,

  iconSize: [25, 41],

  iconAnchor: [12, 41],

});
 
const position: [number, number] = [12.996144, 80.250643];
 
export default function MapLeaflet() {

  return (
<MapContainer

      center={position}

      zoom={16}

      style={{ height: "400px", width: "100%", borderRadius: "12px" }}
>
<TileLayer

        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'

        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"

      />
<Marker position={position} icon={customIcon}>
<Popup>Here is the location 📍</Popup>
</Marker>
</MapContainer>

  );

}

 