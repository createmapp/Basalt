import React from 'react';
import { Building, ShoppingCart, Heart, Smartphone, Lightbulb } from 'lucide-react';

const Industries = () => {
  const industries = [
    {
      icon: Building,
      title: 'Banking',
      description: 'Revolutionizing financial services with AI-driven solutions for enhanced customer experience and operational efficiency.',
      solutions: ['Digital Banking Platforms', 'Risk Assessment', 'Automated Compliance', 'Customer Analytics'],
      image: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: ShoppingCart,
      title: 'Retail',
      description: 'Transforming retail experiences through intelligent inventory management, personalized recommendations, and automated operations.',
      solutions: ['Inventory Optimization', 'Customer Personalization', 'Supply Chain AI', 'Demand Forecasting'],
      image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Heart,
      title: 'Healthcare',
      description: 'Advancing healthcare delivery with AI-powered diagnostics, patient management systems, and data analytics.',
      solutions: ['Diagnostic AI', 'Patient Management', 'Medical Data Analytics', 'Telemedicine Platforms'],
      image: 'https://images.pexels.com/photos/3825527/pexels-photo-3825527.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Smartphone,
      title: 'Telecom',
      description: 'Optimizing telecommunications infrastructure with intelligent network management and customer service automation.',
      solutions: ['Network Optimization', 'Predictive Maintenance', 'Customer Support AI', 'Service Analytics'],
      image: 'https://images.pexels.com/photos/442150/pexels-photo-442150.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'Driving innovation across industries with cutting-edge research and development in AI and emerging technologies.',
      solutions: ['R&D Consulting', 'Prototype Development', 'Technology Integration', 'Innovation Strategy'],
      image: 'https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=600'
    }
  ];

  return (
    <section id="industries" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Industries We Serve
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Delivering specialized AI solutions across diverse industries, 
            tailored to meet unique sector requirements and challenges.
          </p>
        </div>

        <div className="space-y-8">
          {industries.map((industry, index) => (
            <div key={index} className={`flex flex-col lg:flex-row items-center gap-12 ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
              <div className="flex-1 space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <industry.icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900">{industry.title}</h3>
                </div>
                <p className="text-gray-600 text-lg leading-relaxed">{industry.description}</p>
                <div className="grid grid-cols-2 gap-3">
                  {industry.solutions.map((solution, solutionIndex) => (
                    <div key={solutionIndex} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      <span className="text-sm text-gray-700">{solution}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex-1">
                <div className="relative rounded-2xl overflow-hidden h-64 shadow-lg">
                  <img 
                    src={industry.image} 
                    alt={`${industry.title} AI Solutions`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent flex items-end">
                    <div className="p-6 text-white">
                      <industry.icon className="h-12 w-12 mb-3" />
                      <div className="text-lg font-semibold">{industry.title} Solutions</div>
                      <div className="text-sm text-gray-200 mt-1">AI-Powered Innovation</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Industries;