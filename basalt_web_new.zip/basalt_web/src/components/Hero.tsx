import React from 'react';
import { ArrowRight, Zap, Shield, TrendingUp } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="pt-16 min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50 flex items-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                AI-Powered
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-600"> Digital Solutions</span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Transform your business with AI Driven Solutions across domains in Banking & Financials, Travel & Logistics, Communications, Geospatial and Drone technolgies.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center space-x-2 group">
                <span>Get Started</span>
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform duration-200" />
              </button>
              <button className="border-2 border-blue-600 text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-blue-600 hover:text-white transition-colors duration-200">
                Learn More
              </button>
            </div>

            <div className="grid grid-cols-3 gap-8 pt-8">
              <div className="text-center">
                <Zap className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">100%</div>
                <div className="text-sm text-gray-600">Secure</div>
              </div>
              <div className="text-center">
                <Shield className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">100%</div>
                <div className="text-sm text-gray-600">Scalability & Reliability</div>
              </div>
              <div className="text-center">
                <TrendingUp className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">Incremental</div>
                <div className="text-sm text-gray-600">ROI</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative w-full h-96 lg:h-[500px] rounded-2xl overflow-hidden shadow-2xl">
              <img 
				src="../AI_innovation_hub_resized.jpeg?auto=compress&cs=tinysrgb&w=800"               
                alt="AI Technology and Digital Innovation"
                className="w-full h-full object-cover"
              />
              {/*
              <div className="absolute inset-0 bg-gradient-to-r from-gray-900/80 to-gray-700/60 flex items-center justify-center">
                <div className="text-center space-y-4 text-white">
                  <div className="w-24 h-24 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto">
                    <Zap className="h-12 w-12 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold">AI Innovation Hub</h3>
                  <p className="text-gray-100">Powered by advanced machine learning algorithms</p>
                </div>
              </div>
              */}
              {/* Floating elements */}
              <div className="absolute top-4 left-4 w-16 h-16 bg-white/90 backdrop-blur-sm rounded-lg shadow-lg flex items-center justify-center animate-pulse">
                <Shield className="h-8 w-8 text-gray-600" />
              </div>
              <div className="absolute bottom-4 right-4 w-16 h-16 bg-white/90 backdrop-blur-sm rounded-lg shadow-lg flex items-center justify-center animate-pulse">
                <TrendingUp className="h-8 w-8 text-grey-600" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;