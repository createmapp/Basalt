import React from 'react';
import { Bot, DollarSign, Building2, Shield, Settings } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Bot,
      title: 'AI Automation',
      description: 'Intelligent process automation using machine learning algorithms to streamline operations and reduce manual work.',
      features: ['Process Automation', 'Predictive Analytics', 'Natural Language Processing', 'Computer Vision'],
      image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: DollarSign,
      title: 'Financial Services',
      description: 'Comprehensive financial technology solutions including payment processing, risk assessment, and regulatory compliance.',
      features: ['Payment Solutions', 'Risk Management', 'Fraud Detection', 'Compliance Automation'],
      image: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: Building2,
      title: 'Banking Solutions',
      description: 'Next-generation banking platforms with AI-powered features for enhanced customer experience and operational efficiency.',
      features: ['Core Banking Systems', 'Digital Wallets', 'Loan Processing', 'Customer Analytics'],
      image: 'https://images.pexels.com/photos/6801874/pexels-photo-6801874.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: Shield,
      title: 'Cybersecurity Solutions',
      description: 'Advanced security frameworks protecting your digital assets with AI-driven threat detection and prevention.',
      features: ['Threat Detection', 'Security Audits', 'Compliance Management', 'Incident Response'],
      image: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: Settings,
      title: 'IT Consulting Services',
      description: 'Strategic technology consulting to guide your digital transformation journey with expert insights and implementation.',
      features: ['Digital Strategy', 'System Integration', 'Cloud Migration', 'Technology Roadmap'],
      image: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive AI-powered solutions designed to transform your business operations 
            and drive sustainable growth across all sectors.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 group">
              <div className="w-full h-32 mb-6 rounded-lg overflow-hidden">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors duration-300">
                <service.icon className="h-6 w-6 text-blue-600 group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">{service.title}</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center space-x-2 text-sm text-gray-700">
                    <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <button className="bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors duration-200">
            Explore All Services
          </button>
        </div>
      </div>
    </section>
  );
};

export default Services;