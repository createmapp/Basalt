// SimpleMap.tsx
import { useEffect } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const SimpleMap = () => {
  useEffect(() => {
    // Initialize map
    const map = L.map("map").setView([12.996144, 80.250643], 16);

    // Add OpenStreetMap tiles
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(map);

    // Add marker
    L.marker([12.996144, 80.250643])
      .addTo(map)
      .bindPopup("Basalt Digital 📍")
      .openPopup();

    return () => {
      map.remove();
    };
  }, []);

  return (
    <div
      id="map"
      style={{ height: "400px", width: "100%", borderRadius: "12px" }}
    />
  );
};

export default SimpleMap;
